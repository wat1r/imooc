package cn.itcast.dao;

public interface PersonDao {

	public abstract void add();

}