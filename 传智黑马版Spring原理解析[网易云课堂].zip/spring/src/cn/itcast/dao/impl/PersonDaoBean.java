package cn.itcast.dao.impl;

import org.springframework.stereotype.Repository;

import cn.itcast.dao.PersonDao;

@Repository
public class PersonDaoBean implements PersonDao {

	
	
	public void add(){
		System.out.println("ִ��PersonDaoBean��add��������");
	}
}
