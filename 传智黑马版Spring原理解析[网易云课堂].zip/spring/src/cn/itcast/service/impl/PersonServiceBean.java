package cn.itcast.service.impl;

import java.util.HashSet;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import junit.test.ItcastResource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import cn.itcast.dao.PersonDao;
import cn.itcast.service.PersonService;

@Service("personService")
@Scope("prototype")
public class PersonServiceBean implements PersonService {
	// 14'05''
	// @Resource
	// @Autowired(required = true)
	// Ĭ�ϰ����ͽ���ƥ��
	@ItcastResource
	private PersonDao personDao;
	private String name;

	public PersonServiceBean() {
	}

	
	public PersonServiceBean(PersonDao personDao, String name) {
		this.personDao = personDao;
		this.name = name;
	}

	// private Set<String> sets = new HashSet<String>();

	// public Set<String> getSets() {
	// return sets;
	// }
	//
	// public void setSets(Set<String> sets) {
	// this.sets = sets;
	// }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public PersonDao getPersonDao() {
		return personDao;
	}

	// @Resource
//	@ItcastResource
	public void setPersonDao(PersonDao personDao) {
		this.personDao = personDao;
	}

	@PostConstruct
	public void init() {
		System.out.println("��ʼ��");
	}

	//
	// public PersonServiceBean() {
	// System.out.println("�ұ�ʵ������");
	// }

	public void save() {
		// System.out.println(name);
		personDao.add();
	}

//	@PreDestroy
//	public void destory() {
//		System.out.println("���ٷ���");
//	}
}
