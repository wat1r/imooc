package cn.itcast.service;

import java.util.Set;

public interface PersonService {

	public abstract void save();

//	public abstract Set<String> getSets();

}