package junit.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.itcast.dao.impl.PersonDaoBean;
import cn.itcast.service.PersonService;

public class SpringTest {

	// ItcastClassPathXMLApplicationContext
	// ClassPathXmlApplicationContext
	// AbstractApplicationContext
	@Test
	public void instanceSpring() throws Exception {

		ItcastClassPathXMLApplicationContext ctx = new ItcastClassPathXMLApplicationContext(
				"beans.xml");
		PersonService personService = (PersonService) ctx
				.getBean("personService");//Ĭ�ϵ�Bean����
		personService.save();
		
//		PersonService personService1 = (PersonService) ctx
//				.getBean("personService");//Ĭ�ϵ�Bean����
//		System.out.println(personService==personService1);
		
//		PersonDaoBean personDaoBean = (PersonDaoBean) ctx
//				.getBean("personDaoBean");//Ĭ�ϵ�Bean����
//		System.out.println("personDaoBean:"+personDaoBean);
//		System.out.println("personService:"+personService);
		// PersonService personService = (PersonService) ctx
		// .getBean("personService");
//		 personService.save();
		// for (String value : personService.getSets()) {
		// System.out.println(value);
		// }

		// 9'13'' 1004455455_1
		// PersonService personService2 = (PersonService) ctx
		// .getBean("personService");
		// System.out.println(personService1 == personService2);
//		 ctx.close();

	}
}
