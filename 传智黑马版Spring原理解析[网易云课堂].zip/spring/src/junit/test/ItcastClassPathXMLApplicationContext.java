package junit.test;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.ConvertUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.XPath;
import org.dom4j.io.SAXReader;

public class ItcastClassPathXMLApplicationContext {

	private List<BeanDefinition> beanDefines = new ArrayList<BeanDefinition>();
	private Map<String, Object> sigletons = new HashMap<String, Object>();

	public ItcastClassPathXMLApplicationContext(String fileName)
			throws Exception {
		this.readXML(fileName);
		this.instanceBeans();
		this.annotationInject();
		this.injectObject();
	}

	private void annotationInject() throws Exception {

		for (String beanName : sigletons.keySet()) {
			Object bean = sigletons.get(beanName);
			if (bean != null) {
				PropertyDescriptor[] ps = Introspector.getBeanInfo(
						bean.getClass()).getPropertyDescriptors();
				for (PropertyDescriptor properdesc : ps) {
					Method setter = properdesc.getWriteMethod();// ��ȡ���Ե�setter����
					if (setter != null
							&& setter.isAnnotationPresent(ItcastResource.class)) {
						ItcastResource resource = setter
								.getAnnotation(ItcastResource.class);
						Object value = null;
						if (resource.name() != null
								&& !"".equals(resource.name())) {
							value = sigletons.get(resource.name());
						} else {
							value = sigletons.get(properdesc.getName());
							if (value == null) {
								for (String key : sigletons.keySet()) {
									if (properdesc.getPropertyType()
											.isAssignableFrom(
													sigletons.get(key)
															.getClass())) {
										value = sigletons.get(key);
										break;

									}

								}

							}
						}
						setter.setAccessible(true);
						setter.invoke(bean, value);// �����ö���ע�뵽����

					}

				}

				Field[] fields = bean.getClass().getDeclaredFields();
				for (Field field : fields) {
					if (field.isAnnotationPresent(ItcastResource.class)) {
						ItcastResource resource = field
								.getAnnotation(ItcastResource.class);
						Object value = null;
						if (resource.name() != null
								&& !"".equals(resource.name())) {
							value = sigletons.get(resource.name());
						} else {
							value = sigletons.get(field.getName());
							if (value == null) {
								for (String key : sigletons.keySet()) {
									if (field.getType().isAssignableFrom(
											sigletons.get(key).getClass())) {
										value = sigletons.get(key);
										break;
									}
								}
							}
						}
						field.setAccessible(true);// ��������private�ֶ�
						field.set(bean, value);
					}

				}
			}

		}

	}

	/**
	 * Ϊbean���������ע��ֵ
	 */
	private void injectObject() throws Exception {

		for (BeanDefinition beanDefinition : beanDefines) {
			Object bean = sigletons.get(beanDefinition.getId());
			if (bean != null) {
				PropertyDescriptor[] ps = Introspector.getBeanInfo(
						bean.getClass()).getPropertyDescriptors();
				for (PropertyDefinition propertyDefinition : beanDefinition
						.getPropertyDefinition()) {
					for (PropertyDescriptor properdesc : ps) {
						if (propertyDefinition.getName().equals(
								properdesc.getName())) {
							Method setter = properdesc.getWriteMethod();// ��ȡ���Ե�setter����
							Object value = null; // ,private
							if (setter != null) {
								if (propertyDefinition.getRef() != null
										&& !"".equals(propertyDefinition
												.getRef())) {
									value = sigletons.get(propertyDefinition
											.getRef());
									setter.setAccessible(true);

								} else {
									value = ConvertUtils.convert(
											propertyDefinition.getValue(),
											properdesc.getPropertyType());
								}
								setter.invoke(bean, value);

							}

						}

					}
				}

			}
		}

	}

	/**
	 * ���bean��ʵ����
	 */
	private void instanceBeans() {
		for (BeanDefinition beanDefinition : beanDefines) {
			try {
				if (beanDefinition.getClassName() != null
						&& !"".equals(beanDefinition.getClassName().trim())) {
					sigletons.put(beanDefinition.getId(),
							Class.forName(beanDefinition.getClassName())
									.newInstance());
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * ��ȡbeanʵ��
	 * 
	 * @param beanName
	 * @return
	 */
	public Object getBean(String beanName) {
		return this.sigletons.get(beanName);
	}

	/**
	 * ��ȡxml�����ļ�
	 * 
	 * @param filename
	 */
	private void readXML(String filename) {
		SAXReader saxReader = new SAXReader();
		Document document = null;
		try {
			URL xmlpath = this.getClass().getClassLoader()
					.getResource(filename);
			document = saxReader.read(xmlpath);
			Map<String, String> nsMap = new HashMap<String, String>();
			nsMap.put("ns", "http://www.springframework.org/schema/beans");// ���������ռ�
			XPath xsub = document.createXPath("//ns:beans/ns:bean");// ����beans/bean��ѯ·��
			xsub.setNamespaceURIs(nsMap);// ���������ռ�
			List<Element> beans = xsub.selectNodes(document);// ��ȡ�ĵ�������bean�ڵ�
			for (Element element : beans) {
				String id = element.attributeValue("id");// ��ȡid����ֵ
				String clazz = element.attributeValue("class"); // ��ȡclass����ֵ
				BeanDefinition beanDefine = new BeanDefinition(id, clazz);
				XPath propertysub = element.createXPath("ns:property");
				propertysub.setNamespaceURIs(nsMap);
				List<Element> propertys = propertysub.selectNodes(element);
				for (Element property : propertys) {
					String propertyName = property.attributeValue("name");
					String propertyref = property.attributeValue("ref");
					String propertyValue = property.attributeValue("value");
					// System.out.println(propertyName + "," + propertyref);
					PropertyDefinition propertyDefinition = new PropertyDefinition(
							propertyName, propertyref, propertyValue);
					beanDefine.getPropertyDefinition().add(propertyDefinition);
				}
				// String propertyValue = property.attributeValue("value");
				// PropertyDefinition propertyDefinition = new
				// PropertyDefinition(propertyName, propertyref, propertyValue);
				// }
				beanDefines.add(beanDefine);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
