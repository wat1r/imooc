package com.interview.testOne.basic;

public class RealPlayer {
	public void pictureAdjust() {
		System.out.println("RealPlayer picture is adjusting....");
	}
}
