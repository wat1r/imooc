package com.interview.testOne.basic;


/**
 * ����Adapterģʽ���������Լ���API�� MediaPlayerClassA
 * @author FrankCooper
 *
 */
public class MediaPlayerClassA implements IMediaA {

	private MediaPlayer mediaPlayer;

	public MediaPlayerClassA(MediaPlayer mediaPlayer) {
		this.mediaPlayer = mediaPlayer;
	}
 
	public void fixPicture() {
		mediaPlayer.pictureAdjust();
	}

}
