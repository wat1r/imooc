package com.interview.testOne.basic;

/**
 * ����Adapterģʽ���������Լ���API�� RealPlayerClassA
 * 
 * @author FrankCooper
 * 
 */
public class RealPlayerClassA implements IMediaA {

	private RealPlayer realPlayer;

	public RealPlayerClassA(RealPlayer realPlayer) {
		this.realPlayer = realPlayer;
	}

	public void fixPicture() {
		realPlayer.pictureAdjust();
	}

}
