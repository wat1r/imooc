package com.interview.testOne.basic;

public class MediaPlayer {

	public void pictureAdjust() {
		System.out.println("MediaPlayer picture is adjusting....");
	}
}
