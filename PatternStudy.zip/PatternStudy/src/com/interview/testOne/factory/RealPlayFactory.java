package com.interview.testOne.factory;

import com.interview.testOne.basic.IMediaA;
import com.interview.testOne.basic.RealPlayer;
import com.interview.testOne.basic.RealPlayerClassA;

/**
 * ���󹤳�ģʽ
 * 
 * @author FrankCooper
 * 
 */
public class RealPlayFactory implements MediaFactory {

	public IMediaA produceClassA() {
		return new RealPlayerClassA(new RealPlayer());
	}

}
