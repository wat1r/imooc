package com.interview.testOne.factory;


/*
 * ��̬����ģʽ 
 */
public class AllFactory {

	public static MediaPlayFactory createMediaPlayFactory() {
		return new MediaPlayFactory();
	}

	public static RealPlayFactory createRealPlayFactory() {
		return new RealPlayFactory();
	}

}
