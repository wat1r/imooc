package com.interview.testOne;

import com.interview.testOne.basic.IMediaA;
import com.interview.testOne.factory.AllFactory;

public class Test {

	public static void main(String[] args) {
		
		IMediaA mediaPlay = AllFactory.createMediaPlayFactory().produceClassA();
		mediaPlay.fixPicture();
		IMediaA realPlay = AllFactory.createRealPlayFactory().produceClassA();
		realPlay.fixPicture();
		
	}
}
