package com.imooc.proxy;

public interface Moveable {
	void move();
}
