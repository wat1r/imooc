package com.imooc.cglibproxy;

public class Train {

	
	public void move(){
		
		System.out.println("����ʻ��...");
		
	}
}
