package com.imooc.adapter;

public class NoteBook {

	private ThreePlugIf plug;

	public NoteBook(ThreePlugIf plug) {
		super();
		this.plug = plug;
	}

	public void charge() {

		plug.poewrWithThree();
	}

	public static void main(String[] args) {

	/*	GBTwoPlug two = new GBTwoPlug();
		ThreePlugIf three = new TwoPlugAdapter(two);
		NoteBook noteBook = new NoteBook(three);
		noteBook.charge();*/

		GBTwoPlug two = new GBTwoPlug();
		ThreePlugIf three = new TwoPlugAdapterExtends();
		NoteBook noteBook = new NoteBook(three);
		noteBook.charge();
	
	}

}
