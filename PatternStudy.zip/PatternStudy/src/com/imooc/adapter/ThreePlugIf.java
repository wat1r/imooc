package com.imooc.adapter;

public interface ThreePlugIf {

	public void poewrWithThree();
}
