package com.imooc.pattern.strategy;

public interface FlyingStragety {
	
	void performFly();

}
