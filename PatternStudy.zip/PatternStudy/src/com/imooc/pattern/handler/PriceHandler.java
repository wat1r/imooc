package com.imooc.pattern.handler;

public abstract class PriceHandler {

	/**
	 * ֱ�Ӻ�̣����ڴ�������
	 */
	protected PriceHandler successor;

	public void setSuccessor(PriceHandler successor) {
		this.successor = successor;
	}

	public abstract void processDiscount(float discount);

}
