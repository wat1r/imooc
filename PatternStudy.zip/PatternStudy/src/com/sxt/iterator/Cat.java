package com.sxt.iterator;

public class Cat {
	
	private int id;

	public Cat(int id) {
		super();
		this.id = id;
	}
	
	

}
