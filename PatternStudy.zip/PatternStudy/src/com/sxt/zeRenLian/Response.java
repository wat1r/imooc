package com.sxt.zeRenLian;

public class Response {

	 String responseStr;

	public String getResponseStr() {
		return responseStr;
	}

	public void setResponseStr(String responseStr) {
		this.responseStr = responseStr;
	}
	
	
	

}
