package com.sxt.zeRenLian;

public class FaceFilter implements Filter {

	public void doFilter(Request request, Response response,FilterChain chain) {
		request.requestStr = request.requestStr.replace(":)", "^v^");

	}

}
