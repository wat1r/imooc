package com.sxt.zeRenLian;

public class SesitiveFilter implements Filter {

	public void doFilter(Request request, Response response,FilterChain chain) {
		request.requestStr = request.requestStr.replace("����ҵ", "��ҵ").replace(
				"����", "")+"-----SesitiveFilter";
		chain.doFilter(request, response, chain);
		response.responseStr += "-----SesitiveFilter";

	}
}
