package com.headFirst.observer;

public class Observer1 implements Observer {

	public void update() {
		System.out.println("observer1 has received!");
	}

}
