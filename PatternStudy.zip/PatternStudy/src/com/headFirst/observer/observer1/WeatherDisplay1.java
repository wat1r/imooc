package com.headFirst.observer.observer1;

public class WeatherDisplay1 implements Observer {

	private float temperture;

	public WeatherDisplay1(Subject weather) {
		weather.registerObserver(this);
	}

	public void update(float temp) {
		this.temperture = temp;
		display();
	}

	public void display() {
		System.out.println("display1****:" + this.temperture);
	}
}
