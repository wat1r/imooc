package com.headFirst.observer.observer1;

public interface Observer {

	//�����¶�
	public void update(float temp);
}
