package com.headFirst.observer.observer1;

import java.util.ArrayList;

public class Weather implements Subject {

	private ArrayList<Observer> observers = new ArrayList<Observer>();

	private float temperture;

	public void registerObserver(Observer o) {
		this.observers.add(o);
	}

	public void removeObserver(Observer o) {

		this.observers.remove(o);
	}

	public void notifyObservers() {
		for (int i = 0; i < this.observers.size(); i++) {
			this.observers.get(i).update(temperture);
		}
	}

	public void weatherChange() {
		this.notifyObservers();
	}

	public float getTemperture() {
		return temperture;
	}

	public void setTemperture(float temperture) {
		this.temperture = temperture;
	}

}
