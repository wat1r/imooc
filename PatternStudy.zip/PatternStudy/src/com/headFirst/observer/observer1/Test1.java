package com.headFirst.observer.observer1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Test1 {

	public static void main(String[] args) 
	{
		System.out.println();
		String x3ab = "heh";
		
		
		List<Integer> list = new ArrayList<Integer>();
		
		
		Iterator<Integer> it = list.iterator();
		
		while(it.hasNext()){
			Integer obj = it.next();
			
//			it.remove();
//			list.re
		}
		
		
	}
}
