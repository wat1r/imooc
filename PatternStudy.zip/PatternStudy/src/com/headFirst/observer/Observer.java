package com.headFirst.observer;

public interface Observer {
	public void update();
}
