package com.headFirst.observer;

public class Observer2 implements Observer {

	public void update() {
		System.out.println("observer2 has received!");

	}

}
