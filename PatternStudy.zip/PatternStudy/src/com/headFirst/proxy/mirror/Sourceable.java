package com.headFirst.proxy.mirror;

public interface Sourceable {

	public void method();
}
