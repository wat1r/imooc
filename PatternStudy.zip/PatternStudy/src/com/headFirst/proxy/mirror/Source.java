package com.headFirst.proxy.mirror;

public class Source implements Sourceable {

	public void method() {
		System.out.println("the original method.");
	}

}
