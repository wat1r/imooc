package com.headFirst.proxy;

import java.rmi.*;

/**
 * Զ�̽ӿ�
 * @author FrankCooper
 *
 */
public interface MyRemote extends Remote {

	public String sayHello() throws RemoteException;
	
	
}
