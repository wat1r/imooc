package com.headFirst.proxy;

public class Test {

}
