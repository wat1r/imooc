package com.headFirst.decorator;

public abstract class CondimentDecorator extends Beverage {

	@Override
	public abstract String getDescription();

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 0;
	}

}
