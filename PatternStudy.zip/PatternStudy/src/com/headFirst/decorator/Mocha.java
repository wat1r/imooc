package com.headFirst.decorator;

public class Mocha extends CondimentDecorator {

	private Beverage beverage;

	private double MOCHAPRICE = 0.20;

	public Mocha(Beverage beverage) {
		this.beverage = beverage;
	}

	@Override
	public String getDescription() {
		return beverage.getDescription() + ", Moncha";
	}

	@Override
	public double cost() {
		return MOCHAPRICE + beverage.cost();
	}

}
