package com.headFirst.decorator.test1;

public interface Sourceable {

	public void method();
}
