package com.headFirst.decorator.test1;

public class Source implements Sourceable {

	public void method() {
		System.out.println("the original method!");
	}

}
