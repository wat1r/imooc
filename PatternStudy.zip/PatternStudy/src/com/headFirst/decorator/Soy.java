package com.headFirst.decorator;

public class Soy extends CondimentDecorator {

	private Beverage beverage;

	private double SOYPRICE = 0.15;
;

	public Soy(Beverage beverage) {
		this.beverage = beverage;
	}

	@Override
	public String getDescription() {
		return beverage.getDescription() + ", Soy";
	}

	@Override
	public double cost() {
		return SOYPRICE + beverage.cost();
	}

}
