package com.headFirst.adapter.clazz;

public class Source {
	public void method1() {
		System.out.println("this is original method!");
	}
}
