# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy import Field, Item


class MiaoItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    title = scrapy.Field()
    author = scrapy.Field()
    img = scrapy.Field()
    link = scrapy.Field()



class TopicItem(Item):
    url = Field()
    title = Field()
    author = Field()


class ContentItem(Item):
    url = Field()
    content = Field()
    author = Field()