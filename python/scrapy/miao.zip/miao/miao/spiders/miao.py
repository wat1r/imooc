import scrapy

from miao.items import MiaoItem


class NgaSpider(scrapy.Spider):
    name = 'NgaSpider'
    # host ='http://bbs.ngacn.cc/'
    host = 'https://www.autohome.com.cn/'
    # host ='https://blog.csdn.net/'
    # host ='https://www.baidu.com'
    # start_urls是我们准备爬的初始页
    start_urls = [
        "https://club.autohome.com.cn/jingxuan/292/1?pvareaid=2341162#choisSection",
    ]

    # 这个是解析函数，如果不特别指明的话，scrapy抓回来的页面会由这个函数进行解析。
    # 对页面的处理和分析工作都在此进行，这个示例里我们只是简单地把页面内容打印出来。
    def parse(self, response):
        items_list = response.xpath("//ul[@class='content']/li")
        for i_item in items_list:
            http_header = "https:"
            miao_item = MiaoItem()
            miao_item['title'] = i_item.xpath(".//div[@class='pic_txt']/p/a/text()").extract_first()
            miao_item['author'] = i_item.xpath(
                ".//div[@class='pic_txt']/dl/dt[@class='user']/a/span/text()").extract_first()
            miao_item['img'] = http_header + i_item.xpath(".//div[@class='pic-box']/a/img/@data-original").extract_first()
            miao_item['link'] = http_header + i_item.xpath(
                ".//div[@class='pic-box']/a/@href").extract_first()
            print(miao_item)
            yield miao_item

        # print(response.body)
            # 解析下一个的规则，取后一页的xpath
        next_link = response.xpath("//div[@class='pages']/a[@class='afpage']/@href").extract()
        if next_link:
            next_link = next_link[0]
            yield scrapy.Request("https://club.autohome.com.cn" + next_link, callback=self.parse)
