 package com.yuan.test;

import com.yuan.bean.EmployeeMapper;

public class Test1 {

	
	public static void main(String[] args) {
		
		EmployeeMapper zs = new EmployeeMapper();
		zs.setId("1");
		zs.setGender('0');
		zs.setAddress("��������");
		
		
	}
}
