package com.yuan.test;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.google.gson.Gson;
import com.yuan.bean.Employee;
import com.yuan.dao.EmployeeDao;
import com.yuan.dao.EmployeeDao2;

public class MyBatisTest2 {

	@Test
	public void wan() {

		try {
			// ��õ�ǰMybaits�ܵ������ļ���·��
			String resource = "resource.xml";
			// ��õ�ǰ�����ļ���������
			Reader reader = Resources.getResourceAsReader(resource);
			// ͨ��������������SqlSessionFactory�������ݿ�Ự����
			SqlSessionFactory sqlMapper = new SqlSessionFactoryBuilder()
					.build(reader);
			// ͨ�����ݿ�Ự���������������ݿ��һ�λỰ ����Ϊtrue��Ϊ�Զ��ύ
			SqlSession sqlSession = sqlMapper.openSession(true);

			/*
			 * EmployeeDao employeeDao =
			 * sqlSession.getMapper(EmployeeDao.class);
			 * 
			 * Employee selOne = employeeDao.selOne("1");
			 * System.out.println("selOne:" + new Gson().toJson(selOne));
			 * List<Employee> selAll = employeeDao.selAll();
			 * System.out.println("selAll:" + new Gson().toJson(selAll));
			 */

			EmployeeDao employeeDao = sqlSession.getMapper(EmployeeDao.class);
			Employee employee = new Employee();
			// employee.setId("1");
			employee.setName("UU");
			// employee.setGender('1');
			employee.setAddress("Japan");
			// employeeDao.insertEmp(employee);

			// employeeDao.updateEmp(employee);

			// employeeDao.deleteOne("2");

			// List<Employee> list = employeeDao.selAll();
			// System.out.println("list:" + new Gson().toJson(list));
			// List<Employee> queryList = employeeDao.queryList("U",'1');
			// System.out.println("queryList:" + new Gson().toJson(queryList));

			// Map map = new HashMap();
			// map.put("name", "U");
			// map.put("gender", '1');
			//
			// List<Employee> queryList2 = employeeDao.queryList2(map);

			// List<Employee> queryByIf = employeeDao.queryByIf(employee);
			// List<Employee> queryByChoose =
			// employeeDao.queryByChoose(employee);

			// List<Employee> result = employeeDao.queryByTrim(employee);
			// List<Employee> result = employeeDao.queryByWhere(employee);
			// System.out.println("result:"
			// + new Gson().toJson(result));

			List list = new ArrayList();
			list.add("1");
			list.add("2");
			// int result = employeeDao.deleteByList(list);
			String[] strs = { "3", "4" };
			int result = employeeDao.deleteByArray(strs);
			System.out.println("result:" + new Gson().toJson(result));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
