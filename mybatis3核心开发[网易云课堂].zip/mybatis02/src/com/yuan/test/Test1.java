 package com.yuan.test;

import com.yuan.bean.Employee;

public class Test1 {

	
	public static void main(String[] args) {
		
		Employee zs = new Employee();
		zs.setId("1");
		zs.setGender('0');
		zs.setAddress("��������");
		
		
	}
}
