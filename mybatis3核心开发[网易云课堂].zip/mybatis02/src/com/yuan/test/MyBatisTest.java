package com.yuan.test;

import java.io.IOException;
import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.google.gson.Gson;
import com.yuan.bean.Employee;
import com.yuan.dao.EmployeeDao;
import com.yuan.dao.EmployeeDao2;

public class MyBatisTest {

	@Test
	public void wan() {

		try {
			// ��õ�ǰMybaits�ܵ������ļ���·��
			String resource = "resource.xml";
			// ��õ�ǰ�����ļ���������
			Reader reader = Resources.getResourceAsReader(resource);
			// ͨ��������������SqlSessionFactory�������ݿ�Ự����
			SqlSessionFactory sqlMapper = new SqlSessionFactoryBuilder()
					.build(reader);
			// ͨ�����ݿ�Ự���������������ݿ��һ�λỰ ����Ϊtrue��Ϊ�Զ��ύ
			SqlSession sqlSession = sqlMapper.openSession(true);

			/*
			 * EmployeeDao employeeDao =
			 * sqlSession.getMapper(EmployeeDao.class);
			 * 
			 * Employee selOne = employeeDao.selOne("1");
			 * System.out.println("selOne:" + new Gson().toJson(selOne));
			 * List<Employee> selAll = employeeDao.selAll();
			 * System.out.println("selAll:" + new Gson().toJson(selAll));
			 */

			// EmployeeDao2 employeeDao2 =
			// sqlSession.getMapper(EmployeeDao2.class);
			// List<Employee> list = employeeDao2.getAll();

			EmployeeDao2 employeeDao2 = sqlSession
					.getMapper(EmployeeDao2.class);
			// List<Employee> list = employeeDao2.selectAll3();
			// List<Employee> list = employeeDao2.selectAll4();
			List<Employee> list = employeeDao2.selectStep("1");

			System.out.println("list:"
					+ new Gson().toJson(list.get(0).getName()));
			// System.out.println("list:" + new Gson().toJson(list));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
