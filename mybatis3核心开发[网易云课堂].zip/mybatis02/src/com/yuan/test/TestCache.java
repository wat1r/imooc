package com.yuan.test;

import java.io.IOException;
import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.google.gson.Gson;
import com.yuan.bean.Employee;
import com.yuan.dao.EmployeeDao2;

public class TestCache {

	public static SqlSessionFactory getSqlSession() {

		String resource = "resource.xml";
		// ��õ�ǰ�����ļ���������
		Reader reader;
		try {
			reader = Resources.getResourceAsReader(resource);
			// ͨ��������������SqlSessionFactory�������ݿ�Ự����
			SqlSessionFactory sqlMapper = new SqlSessionFactoryBuilder()
					.build(reader);
			// ͨ�����ݿ�Ự���������������ݿ��һ�λỰ ����Ϊtrue��Ϊ�Զ��ύ
			return sqlMapper;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public static void main(String[] args) {

		SqlSessionFactory sqlSessionFactory = getSqlSession();
		SqlSession session = sqlSessionFactory.openSession();
		EmployeeDao2 employeeDao2 = session.getMapper(EmployeeDao2.class);
		long s1 = System.currentTimeMillis();
		List<Employee> list = employeeDao2.selectAll3();
		System.out.println("list:" + new Gson().toJson(list));
		long e1 = System.currentTimeMillis();
		System.out.println("��һ�β�ѯʱ�䣺"+(e1-s1));
		
		//
//		session.clearCache();
//		PerpetualCache
		
		long s2 = System.currentTimeMillis();
		List<Employee> list2 = employeeDao2.selectAll3();
		System.out.println("list2:" + new Gson().toJson(list2));
		long e2 = System.currentTimeMillis();
		System.out.println("��һ�β�ѯʱ�䣺"+(e2-s2));
		
		
		session.close();
		
	}

}
