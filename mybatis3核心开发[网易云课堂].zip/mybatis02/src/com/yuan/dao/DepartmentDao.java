package com.yuan.dao;

import com.yuan.bean.Department;

public interface DepartmentDao {

	public Department getDepartmentById(String id);

}
