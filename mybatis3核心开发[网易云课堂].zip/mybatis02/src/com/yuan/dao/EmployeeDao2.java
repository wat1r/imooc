package com.yuan.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.yuan.bean.Employee;

public interface EmployeeDao2 {

	// // ��ѯ����
	// @Select("select * from employee")
	// public List<Employee> getAll();
	//
	// // ��ѯ��һ
	// public Employee selOne(String id);

	public List<Employee> selectAll3();

	public List<Employee> selectAll4();

	public List<Employee> selectStep(String id);
	
	

}
