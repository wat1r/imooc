package com.yuan.bean;

import java.io.Serializable;

/*
 * Ա��ʵ����
 */
public class Employee implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2213196253850971774L;

	private String id;

	private String name;

	private char gender;

	private String address;

	private Department dept;
	
	

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
